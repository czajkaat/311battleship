import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.GridLayout;

import javax.swing.BorderFactory;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.LayoutStyle;
import javax.swing.SwingConstants;

public class Checkerboard extends JFrame{

	public static void main(String args[]){
		char[][] boardStatus = {
				{'e', 'b', 'e', 'b', 'e', 'b', 'e', 'b'},
				{'b', 'e', 'b', 'e', 'b', 'e', 'b', 'e'},
				{'e', 'b', 'e', 'b', 'e', 'b', 'e', 'b'},
				{'e', 'e', 'e', 'e', 'e', 'e', 'e', 'e'},
				{'e', 'e', 'e', 'e', 'e', 'e', 'e', 'e'},
				{'r', 'e', 'r', 'e', 'r', 'e', 'r', 'e'},
				{'e', 'r', 'e', 'r', 'e', 'r', 'e', 'r'},
				{'r', 'e', 'r', 'e', 'r', 'e', 'r', 'e'}
		};

		Checkerboard board = new Checkerboard(boardStatus);

	}

	JPanel p = new JPanel();
	JPanel boardPanel = new JPanel();
	JPanel labelPanel = new JPanel();
	JLabel statusLabel = new JLabel("Status");
	JLabel nameLabel = new JLabel("This Program is Written by Adrian Czajka");
	private char[][] charArray;
	

	public Checkerboard(char[][] boardStatus) {
		super();
		this.setSize(418, 500);
		this.setTitle("Let's Play Checkers");
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		charArray = boardStatus;
		
		addComponents();

		this.setVisible(true);

	}

	public void addComponents(){
		CheckerComponent cc = new CheckerComponent ();
		cc.setPreferredSize(new Dimension(400,400));
		cc.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		labelPanel.setLayout(new GridLayout(2,1));
		labelPanel.setPreferredSize(new Dimension(415,50));
		statusLabel.setHorizontalAlignment(SwingConstants.CENTER);
		nameLabel.setHorizontalAlignment(SwingConstants.CENTER);
		labelPanel.add(statusLabel);
		labelPanel.add(nameLabel);

		cc.add(boardPanel);
		this.add(cc, BorderLayout.NORTH);
		this.add(labelPanel, BorderLayout.SOUTH);

	}



	public class CheckerComponent extends JComponent{
		int x;
		int y;
		@Override
		public void paintComponent (Graphics g){
			for(int i = 0; i<8; i++){
				for(int j = 0; j<8; j++){
					g.setColor(Color.BLACK);
					g.drawRect(x, y, 50, 50);
					if(charArray[i][j] == 'b' || charArray[i][j] == 'r'){
						x = 50*j;
						y = 50*i;
						g.setColor(Color.GREEN);
						g.fillRect(x, y, 50, 50);
						if(charArray[i][j] == 'b'){
							g.setColor(Color.BLACK);
							g.fillOval(x+5, y+5, 40, 40);
						}
						else if(charArray[i][j] == 'r'){
							g.setColor(Color.RED);
							g.fillOval(x+5, y+5, 40, 40);
						}
					}
					else if(i == 3){
						x=50*j;
						y=50*i;
						if(j%2 == 0){
							g.setColor(Color.GREEN);
							g.fillRect(x, y, 50, 50);
						}
						if(j%2 == 1){
							g.setColor(Color.WHITE);
							g.fillRect(x,y,50,50);
						}
					}
					else if(i == 4){
						x=50*j;
						y=50*i;
						if(j%2 == 1){
							g.setColor(Color.GREEN);
							g.fillRect(x, y, 50, 50);
						}
						if(j%2 == 0){
							g.setColor(Color.WHITE);
							g.fillRect(x,y,50,50);
						}
					}
					else if(charArray[i][j] == 'e'){
						x = 50*j;
						y = 50*i;
						g.setColor(Color.WHITE);
						g.fillRect(x+1, y+1, 49, 49);
					}

				}
			}
		}

	}
}


